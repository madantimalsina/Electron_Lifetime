#!/bin/bash

#source /cvmfs/lz.opensciencegrid.org/LzBuild/release-latest/LzBuild/setup.sh 
source /cvmfs/lz.opensciencegrid.org/BACCARAT/release-3.14.3/setup.sh
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:`pwd`/rqlib